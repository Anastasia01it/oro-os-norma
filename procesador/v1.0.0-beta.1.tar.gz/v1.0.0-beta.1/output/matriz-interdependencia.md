# MATRIZ DE INTERDEPENDENCIA
# NP-MATRIZ  v1.0.0-beta.1  2026-08-25T18:01:51-0500
# Hash fuente: cd28f9451bceeab2

================================================================================
1.  REGLAS DE PROPAGACION OBLIGATORIAS
================================================================================

| Elemento origen | Evento | Elementos destino | Razon |
|-----------------|--------|-------------------|-------|
| C.3 | Derogada total | D.2, E.5, F.23 | Si una norma se deroga totalmente, se activan relaciones de derogacion, versiones derogadas y vacios normativos. |
| C.12 | Interpretacion autorizada | J.8, G.7 | Si hay interpretacion autorizada, se activa interpretacion conforme y conflictos de interpretacion. |
| F.30 | Formula detectada | F.31, F.32, F.33, F.34 | Si hay formula, deben verificarse variables, procedimiento, casos limite y tablas. |
| F.35 | Indicador detectado | F.35a, F.35b, F.35c | Si hay indicador, verificar metas escalonadas, compuestos y consecuencias. |
| F.36 | Metodologia detectada | F.36a, F.36b, F.36c | Si hay metodologia, verificar principios, validacion y aprobacion. |
| A.30 | Caracter particular | A.31, M.7 | Si la norma es de caracter particular, verificar publicidad y recursos especificos. |

================================================================================
2.  MAPA DE IMPACTO POR CATEGORIA
================================================================================

| Origen \ Destino | A | B | C | D | E | F | G | H | I | J | K | L | M |
|--------|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **A** | — | · | · | · | · | · | · | · | · | · | · | · | · |
| **B** | · | — | · | · | · | · | · | · | · | · | · | · | · |
| **C** | · | · | — | · | · | · | · | · | · | · | · | · | · |
| **D** | · | · | · | — | · | · | · | · | · | · | · | · | · |
| **E** | · | · | · | · | — | · | · | · | · | · | · | · | · |
| **F** | · | · | · | · | · | — | · | · | · | · | · | · | · |
| **G** | · | · | · | · | · | · | — | · | · | · | · | · | · |
| **H** | · | · | · | · | · | · | · | — | · | · | · | · | · |
| **I** | · | · | · | · | · | · | · | · | — | · | · | · | · |
| **J** | · | · | · | · | · | · | · | · | · | — | · | · | · |
| **K** | · | · | · | · | · | · | · | · | · | · | — | · | · |
| **L** | · | · | · | · | · | · | · | · | · | · | · | — | · |
| **M** | · | · | · | · | · | · | · | · | · | · | · | · | — |

================================================================================
3.  INDICE DE SENSIBILIDAD POR CATEGORIA
================================================================================

| Categoria | Elementos | Conexiones salientes | Score de sensibilidad |
|-----------|-----------|----------------------|----------------------|
| A | 27 | 0 | ★☆☆☆☆ |
| B | 22 | 0 | ★☆☆☆☆ |
| C | 20 | 0 | ★☆☆☆☆ |
| D | 24 | 0 | ★☆☆☆☆ |
| E | 13 | 0 | ★☆☆☆☆ |
| F | 71 | 0 | ★☆☆☆☆ |
| G | 17 | 0 | ★☆☆☆☆ |
| H | 12 | 0 | ★☆☆☆☆ |
| I | 6 | 0 | ★☆☆☆☆ |
| J | 10 | 0 | ★☆☆☆☆ |
| K | 10 | 0 | ★☆☆☆☆ |
| L | 20 | 0 | ★☆☆☆☆ |
| M | 16 | 0 | ★☆☆☆☆ |
