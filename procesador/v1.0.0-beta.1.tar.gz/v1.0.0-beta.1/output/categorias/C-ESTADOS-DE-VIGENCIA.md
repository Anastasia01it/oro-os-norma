# CATEGORIA C — ESTADOS DE VIGENCIA
# NP-CAT-C  v1.0.0-beta.1  2026-08-25T18:01:49-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 20 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
C.1   Vigente (sin modificaciones)          Norma en pleno efecto sin alteraciones
C.2   Vigente (modificada)                  Norma en efecto pero con cambios posteriores
C.3   Derogada (total)                      Norma eliminada completamente por otra
C.4   Derogada (parcial)                    Algunas disposiciones eliminadas
C.5   Caduca / Expirada                     Perdio vigencia por transcurso de tiempo o condicion
C.6   Suspensa (eficacia suspendida)        Aplicacion temporalmente detenida
C.7   Nula / Inexistente                    Sin efectos juridicos desde su origen
C.8   En tramite / Proyecto                 No ha sido aprobada ni publicada
C.9   Vigente con reservas                  Aplica con limitaciones declaradas
C.10  Vigente con declaratoria de inexequibilidad parcial Parte declarada inconstitucional, resto vigente
C.11  Vigente con sentencia de inconstitucionalidad condicionada Vigente bajo condiciones interpretativas
C.12  Vigente con interpretacion autorizada Aplica segun interpretacion oficial
C.13  Derogada tacitamente (por incompabilidad) Eliminada implicitamente por norma incompatible
C.14  Consolidada (texto unificado)         Version integrada con todas las modificaciones
C.15  Vigencia diferida (entrada en vigor aplazada) Aprobada pero aun no en efecto
C.16  Vigencia escalonada (por articulos o materias) Diferentes partes entran en vigor en fechas distintas
C.17  Vigente con eficacia diferida         Publicada y vigente, pero algunos efectos aplazados
C.18  Vigente con interpretacion conforme   Aplicable solo si se interpreta compatible con norma superior
C.19  Con efectos retroactivos              Aplica a hechos anteriores a su entrada en vigor
C.20  Con efectos ultraactivos              Sigue produciendo efectos tras su derogacion

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | C |
| Elementos      | 20 |
| Fase principal | 2 |
| Origenes       | base |
| Hash fuente    | 168b05005897172f |
