# CATEGORIA D — RELACIONES NORMATIVAS
# NP-CAT-D  v1.0.0-beta.1  2026-08-25T18:01:49-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 24 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
D.1   Deroga (explicitamente)               Norma que elimina otras
D.2   Derogada por                          Norma que la elimino
D.3   Modifica (a otra norma)               Norma que altera otra
D.4   Modificada por                        Norma que la altero
D.5   Complementa (a otra norma)            Norma que anade a otra
D.6   Complementada por                     Norma que la anadio
D.7   Desarrolla / Reglamenta               Norma que detalla otra
D.8   Desarrollada / Reglamentada por       Norma que la detallo
D.9   Interpreta (a otra norma)             Norma que aclara otra
D.10  Interpretada por                      Norma que la aclaro
D.11  Confirma / Reitera                    Norma que ratifica otra
D.12  Confirmada / Reiterada por            Norma que la ratifico
D.13  Remite a otra norma (referencia)      Cita o remision externa
D.14  Remitida por                          Norma que la cita
D.15  Principios generales del derecho aplicables Principios que informan la interpretacion (buena fe, proscripcion de lo indefenso)
D.16  Costumbre juridica aplicable          Practicas reiteradas y aceptadas como obligatorias
D.17  Reglas de interpretacion aplicables   Metodos hermeneuticos relevantes (literal, sistematico, teleologico, historico)
D.18  Analogia / Integracion del derecho    Normas de relleno aplicables por vacio
D.19  Es derivado de                        Norma de la cual deriva su contenido
D.20  Basado en                             Fundamento normativo o tecnico
D.21  Corrige a                             Enmienda o correccion de error
D.22  Transposicion de directivas           Adaptacion de normativa europea
D.25  Paquete normativo / Regimen normativo Conjunto de normas interdependientes que deben aplicarse en conjunto. Incluye: norma madre, reglamentarias, tecnicas, actos administrativos complementarios, jerarquia interna, obligatoriedad conjunta, mecanismo de actualizacion. [CRA]
D.25a Conceptos tecnicos y orientaciones regulatorias Actos administrativos de interpretacion, conceptos, guias, manuales u orientaciones emitidos por la autoridad que complementan la aplicacion sin fuerza normativa propiamente dicha, pero generan expectativas legitimas. [CRA]

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | D |
| Elementos      | 24 |
| Fase principal | 4 |
| Origenes       | CRA, base |
| Hash fuente    | 4dbf050605ea5b7c |
