# CATEGORIA I — JERARQUIA Y VALIDEZ FORMAL
# NP-CAT-I  v1.0.0-beta.1  2026-08-25T18:01:50-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 6 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
I.1   Rango en la jerarquia normativa       Posicion en la piramide de Kelsen / ordenamiento propio
I.2   Competencia para expedir              Tenia la autoridad emisora competencia material y territorial
I.3   Procedimiento de formacion            Se siguieron los pasos formales (debate, lecturas, aprobacion, sancion, promulgacion)
I.4   Vicios formales detectados            Inobservancia de quorum, tramite, competencia, motivacion
I.5   Control previo realizado              Control de constitucionalidad previo, consulta previa, referendum
I.6   Control posterior pendiente           Acciones de inconstitucionalidad, nulidad, revocatoria en curso

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | I |
| Elementos      | 6 |
| Fase principal | 1 |
| Origenes       | base |
| Hash fuente    | 3212e3ed6f9df296 |
