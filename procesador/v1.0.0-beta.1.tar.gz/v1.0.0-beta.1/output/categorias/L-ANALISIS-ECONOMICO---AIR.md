# CATEGORIA L — ANALISIS ECONOMICO / AIR
# NP-CAT-L  v1.0.0-beta.1  2026-08-25T18:01:50-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 20 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
L.1   Definicion del problema               Situacion que la norma busca resolver
L.2   Objetivos de la norma                 Metas especificas de politica publica
L.3   Alternativas regulatorias consideradas Otras opciones evaluadas antes de la norma elegida
L.4   Costos de cumplimiento para particulares Gastos que deben asumir los regulados
L.5   Costos de cumplimiento para el Estado Gastos de implementacion y seguimiento
L.6   Costos de oportunidad                 Beneficios perdidos por aplicar esta norma y no otra
L.7   Beneficios esperados                  Ganancias sociales, economicas o ambientales
L.8   Impacto distributivo                  Como afecta a diferentes grupos de ingreso
L.9   Impacto sectorial                     Efectos en industrias o sectores especificos
L.10  Impacto ambiental                     Consecuencias ecologicas de la norma
L.11  Consulta publica realizada            Si se consulto a afectados antes de expedir
L.12  Analisis de Impacto Regulatorio (AIR) Documento tecnico de evaluacion ex ante
L.13  Evaluacion ex post                    Revision posterior a la implementacion
L.14  Indicadores de desempeno              Metricas para medir si la norma cumple sus objetivos
L.15  Sunset clause / Clausula de caducidad Fecha automatica de revision o expiracion
L.16  Eficiencia normativa                  Relacion entre costos y beneficios de la norma
L.17  Carga administrativa                  Tiempo y recursos que exige cumplir la norma
L.18  Simplificacion propuesta              Formas de reducir la carga regulatoria
L.19  Innovacion regulatoria                Mecanismos novedosos introducidos
L.20  Lecciones aprendidas                  Conclusiones para futuras normas

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | L |
| Elementos      | 20 |
| Fase principal | 8 |
| Origenes       | base |
| Hash fuente    | b47f78ab02cbc2e6 |
