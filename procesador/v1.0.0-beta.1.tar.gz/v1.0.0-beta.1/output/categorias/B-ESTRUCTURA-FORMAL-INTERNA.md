# CATEGORIA B — ESTRUCTURA FORMAL INTERNA
# NP-CAT-B  v1.0.0-beta.1  2026-08-25T18:01:49-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 22 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
B.1   Preambulo / Exposicion de motivos     La norma se organiza en libros como unidad superior de estructura. Cada libro agrupa partes tematicas coherentes. El numero de libros y su denominacion deben registrarse.
B.2   Titulo(s)                             Division mayor de la norma
B.3   Capitulo(s)                           Subdivision dentro de un titulo
B.4   Seccion(es) / Apartado(s)             Subdivision dentro de un capitulo
B.5   Articulo(s)                           Unidad normativa basica con numeracion
B.6   Paragrafo(s)                          Aclaracion o complemento de un articulo
B.7   Numeral(es) / Inciso(s)               Subdivision dentro de un articulo
B.8   Literal(es) / Letra(s)                Opciones o alternativas dentro de un numeral
B.9   Disposiciones adicionales             Normas complementarias no integradas en el cuerpo principal
B.10  Disposiciones transitorias            Reglas temporales para la transicion
B.11  Disposicion derogatoria               Norma que deroga otras normas
B.12  Disposicion final                     Ultima disposicion de la norma (puede incluir vigencia)
B.13  Anexo(s) / Apendice(s)                Documentos adjuntos con valor normativo
B.14  Glosario / Definiciones               Terminos tecnicos definidos dentro de la norma
B.15  Considerandos / Visto / Resuelvo      En actos administrativos, sentencias, decretos: motivacion previa
B.16  Consideraciones / Fundamentos         Razones de hecho y de derecho que sustentan la norma
B.17  Clausula de extincion / Termino       Fecha o evento que pone fin automatico a la norma
B.18  Clausula de revision / Revision periodica Obligacion de revisar la norma tras cierto tiempo
B.19  Es anexo de                           Norma de la cual este documento es anexo
B.20  Anexos tecnicos con contenido matematico Documentos adjuntos que contienen formulas, modelos, simulaciones o calculos actuariales. [CRA]
B.21  Formatos obligatorios / Formularios   Plantillas, formularios o formatos de presentacion que la norma exige utilizar. Cada formato: codigo, nombre, version, fecha de vigencia, obligatoriedad, norma creadora. [CRA]
B.22  Version de formatos                   Historial de versiones de cada formato obligatorio. Un formato puede actualizarse por resolucion sin modificar la norma sustantiva. [CRA]

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | B |
| Elementos      | 22 |
| Fase principal | 1 |
| Origenes       | CRA, base |
| Hash fuente    | cc0f0e86cbd9cd86 |
