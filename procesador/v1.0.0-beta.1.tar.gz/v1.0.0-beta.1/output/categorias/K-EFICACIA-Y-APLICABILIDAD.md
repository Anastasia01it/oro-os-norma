# CATEGORIA K — EFICACIA Y APLICABILIDAD
# NP-CAT-K  v1.0.0-beta.1  2026-08-25T18:01:50-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 10 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
K.1   Eficacia inmediata                    Produce efectos desde la entrada en vigor
K.2   Eficacia diferida                     Efectos aplazados para ciertos sujetos o materias
K.3   Eficacia condicionada                 Sujeta a evento, acto o resolucion posterior
K.4   Eficacia retroactiva                  Afecta hechos anteriores a su entrada en vigor (excepcional)
K.5   Eficacia ultraactiva                  Efectos que perduran tras la derogacion
K.6   Aplicabilidad personal                Sujetos concretos alcanzados
K.7   Aplicabilidad material                Conductas o situaciones concretas alcanzadas
K.8   Aplicabilidad temporal                Momentos o periodos concretos alcanzados
K.9   Aplicabilidad territorial             Espacios geograficos concretos alcanzados
K.10  Inaplicabilidad por inconstitucionalidad Norma vigente pero no aplicable en caso concreto

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | K |
| Elementos      | 10 |
| Fase principal | 2 |
| Origenes       | base |
| Hash fuente    | 625aadd1afd0e229 |
