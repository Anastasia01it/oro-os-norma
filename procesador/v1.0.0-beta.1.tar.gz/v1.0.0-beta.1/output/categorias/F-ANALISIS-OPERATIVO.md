# CATEGORIA F — ANALISIS OPERATIVO
# NP-CAT-F  v1.0.0-beta.1  2026-08-25T18:01:50-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 71 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
F.1   Sujetos obligados                     Quienes deben cumplir la norma
F.2   Sujetos beneficiarios                 Quienes se benefician de la norma
F.3   Sujetos con facultades                Quienes tienen potestades segun la norma
F.4   Objeto regulado                       Materia o conducta que la norma regula
F.5   Deberes / Obligaciones                Acciones que la norma impone
F.6   Prohibiciones                         Acciones que la norma vedan
F.7   Facultades / Potestades               Poderes conferidos por la norma
F.8   Derechos reconocidos                  Prerrogativas otorgadas por la norma
F.9   Procedimientos                        Pasos formales para ejercer un derecho o cumplir una obligacion
F.10  Requisitos formales                   Documentos, formatos o condiciones exigidas
F.10a Requisitos de diligenciamiento de formatos Instrucciones especificas sobre como llenar los formatos [CRA]
F.11  Requisitos tecnicos                   Estandares, especificaciones o condiciones tecnicas exigidas
F.12  Plazos                                Tiempos maximos o minimos para actuar
F.13  Periodicidades                        Frecuencia con que debe cumplirse (mensual, anual, etc.)
F.14  Umbrales / Montos                     Limites numericos que activan o desactivan obligaciones
F.15  Sanciones                             Consecuencias juridicas del incumplimiento
F.16  Excepciones                           Casos en que la norma no aplica
F.17  Casos especiales                      Situaciones atipicas contempladas
F.18  Regimen transitorio                   Normas temporales para la transicion
F.19  Regimen especial                      Reglas diferenciadas para un grupo especifico
F.20  Clausula de revision                  Obligacion de revisar la norma tras cierto tiempo
F.21  Clausula de salvaguarda               Mecanismo de proteccion ante circunstancias imprevistas
F.22  Condicionantes                        Requisitos que deben cumplirse para que la norma opere
F.23  Vacios normativos detectados          Ausencia de regulacion donde se requeriria
F.24  Ambiguedades detectadas               Texto susceptible de multiples interpretaciones
F.25  Contradicciones detectadas            Inconsistencias internas o con otras normas
F.30  Formulas de calculo / Algoritmos aplicables Ecuaciones, algoritmos o procedimientos matematicos contenidos en la norma [CRA]
F.30a Sistema de formulas / Grafo de dependencias Mapa de interrelaciones entre todas las formulas de la norma [CRA]
F.30b Formulas condicionales                Ecuaciones que cambian segun condiciones explicitas [CRA]
F.30c Formulas iterativas o de convergencia Procedimientos que requieren repeticion hasta alcanzar valor estable [CRA]
F.30d Orden de ejecucion de formulas        Secuencia numerada en que deben aplicarse las formulas [CRA]
F.30e Validacion cruzada entre formulas     Comprobaciones de consistencia aritmetica entre formulas [CRA]
F.31  Variables de entrada                  Datos o factores que deben conocerse para aplicar la formula [CRA]
F.32  Procedimiento de calculo paso a paso  Orden de operaciones, reglas de redondeo, truncamiento [CRA]
F.33  Casos limite y excepciones de la formula Situaciones donde la formula no aplica o requiere tratamiento especial [CRA]
F.34  Tablas de valores o matrices de referencia Anexos numericos, tablas de tarifas progresivas, matrices de correlacion [CRA]
F.35  Indicadores / Metricas / KPIs de cumplimiento Variables cuantificables con las que se mide el cumplimiento [CRA]
F.35a Metas escalonadas de indicadores      Metas que aumentan progresivamente en el tiempo [CRA]
F.35b Indicadores compuestos / Indices agregados Indicadores que resultan de combinacion ponderada de subindicadores [CRA]
F.35c Consecuencias por incumplimiento de indicadores Sanciones, planes de mejoramiento, intervenciones por no cumplir indicador [CRA]
F.36  Metodologias tecnicas aplicables      Conjuntos estructurados de principios, criterios, pasos, validaciones [CRA]
F.36a Principios rectores de la metodologia Principios que orientan la aplicacion de la metodologia [CRA]
F.36b Criterios de validacion de la metodologia Condiciones que debe cumplir el resultado para ser valido [CRA]
F.36c Procedimiento de aprobacion de la metodologia Pasos para que la metodologia sea aprobada por la autoridad [CRA]
F.37  Cronograma de implementacion / Fases  Division del cumplimiento en etapas secuenciales [CRA]
F.37a Hitos criticos                        Eventos o fechas que desencadenan efectos normativos [CRA]
F.37b Periodos de transicion                Regimenes temporales entre fases o entre normas [CRA]
F.41  Mecanismos de ajuste y revision automatica Reglas de actualizacion automatica de valores sin nueva norma [CRA]
F.41a Indexadores y parametros de referencia Indices, valores de referencia o parametros externos que alimentan ajustes [CRA]
F.42  Subsidios, compensaciones y mecanismos de equidad Sistemas de transferencia economica establecidos por la norma [CRA]
F.42a Mecanismos de financiacion de subsidios Como se financian los subsidios [CRA]
F.43  Zonas tarifarias / Areas de servicio / Diferenciacion territorial Division geografica con reglas diferenciadas [CRA]
F.44  Estandares tecnicos de referencia     Normas tecnicas, protocolos, guias o estandares externos incorporados por remision [CRA]
F.45  Modelos y simulaciones tecnicas       Modelos matematicos, computacionales o de simulacion exigidos [CRA]
F.46  Escenarios y analisis de sensibilidad Conjuntos de supuestos y proyecciones exigidos [CRA]
F.46a Matriz de riesgos                     Identificacion de riesgos con probabilidad, impacto y mitigacion [CRA]
F.51  Penalidades progresivas y escalonadas Sistemas de sanciones que varian segun gravedad o reincidencia [CRA]
F.57  Facturacion, cobro, suspension y reconexion Reglas del ciclo comercial entre prestador y usuario [SSPD]
F.57a Prohibiciones de suspension y garantias de continuidad Situaciones donde esta prohibido suspender el servicio [SSPD]
F.58  Interconexion y acceso a infraestructura Reglas de acceso de terceros a redes o infraestructura [SSPD]
F.60  Medidas de urgencia y emergencia      Actuaciones inmediatas ante riesgos inminentes [SSPD]
F.61  Liquidacion, extincion y traspaso de prestadores Reglas para el cese de operaciones y transferencia de usuarios [SSPD]
F.62  Regulacion asimetrica y poder de mercado Diferenciacion de obligaciones segun posicion de mercado [SSPD]
F.63  Condiciones uniformes de servicio     Obligaciones minimas inmodificables por contrato [SSPD]
F.64  Tarifas reguladas vs. tarifas libres / precios de mercado Distincion entre servicios con precio fijado por autoridad y precio de mercado [SSPD]
F.65  Obligaciones de informacion al regulador / supervisor Requerimientos de suministro de informacion especifica a la autoridad [SSPD]
F.66  Medicion, verificacion y disputas de consumo Reglas sobre medidores, homologacion, verificacion y resolucion de disputas [SSPD]
F.67  Fondos sectoriales y compensaciones entre prestadores Mecanismos de transferencia economica entre sujetos regulados [SSPD]
F.70  Sistemas de informacion y plataformas digitales Obligaciones, requisitos o funcionalidades de sistemas informaticos, plataformas digitales, portales web o aplicaciones moviles establecidos por la norma para la prestacion de servicios, tramites o reportes. [CAMPO]
F.71  Ciberseguridad y proteccion de datos  Requisitos de seguridad informatica, protocolos de proteccion de datos personales, cifrado, autenticacion y medidas de resiliencia cibernetica establecidos por la norma. [CAMPO]
F.72  Inteligencia artificial y algoritmos automatizados Uso de sistemas de inteligencia artificial, aprendizaje automatico o algoritmos automatizados para la toma de decisiones, asignacion de recursos o evaluacion de elegibilidad, con sus requisitos de transparencia y explicabilidad. [CAMPO]

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | F |
| Elementos      | 71 |
| Fase principal | 5 |
| Origenes       | CRA, SSPD, base, campo |
| Hash fuente    | b992a0f6f66ff583 |
