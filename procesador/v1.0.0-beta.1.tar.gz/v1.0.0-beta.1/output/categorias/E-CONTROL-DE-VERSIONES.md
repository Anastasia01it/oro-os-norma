# CATEGORIA E — CONTROL DE VERSIONES
# NP-CAT-E  v1.0.0-beta.1  2026-08-25T18:01:49-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 13 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
E.1   Texto original                        Version tal como fue publicada inicialmente
E.2   Texto consolidado                     Version actualizada con todas las modificaciones aplicadas
E.3   Historial de modificaciones           Lista cronologica de normas que alteraron el texto
E.4   Articulos modificados                 Articulos cuyo texto ha cambiado
E.5   Articulos derogados                   Articulos eliminados del texto
E.6   Articulos adicionados                 Articulos nuevos insertados
E.7   Articulos transitorios vigentes       Cuales transitorios aun producen efectos
E.8   Notas de vigencia por articulo        Estado individual de cada disposicion
E.9   Fecha de ultima consolidacion         Cuando se actualizo el texto consolidado
E.10  Versiones intermedias                 Textos entre modificaciones sucesivas
E.11  Marcas de cambio                      Indicadores visuales de que cambio y cuando
E.12  Texto anterior / Texto nuevo          Comparativa lado a lado de modificaciones
E.13  Version de formatos asociados         Registro de cambios en los formatos vinculados a la norma. Diferente de E.1-E.12 (versiones del texto normativo). Un formato puede actualizarse por resolucion sin modificar la norma sustantiva. [CRA]

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | E |
| Elementos      | 13 |
| Fase principal | 3 |
| Origenes       | CRA, base |
| Hash fuente    | eba7e4deb487dc9e |
