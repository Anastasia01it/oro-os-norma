# CATEGORIA H — ELEMENTOS ESPECIALES
# NP-CAT-H  v1.0.0-beta.1  2026-08-25T18:01:50-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 12 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
H.1   Plazo de duracion                     Tiempo maximo de vigencia de la norma
H.2   Objetivo especifico / Meta            Resultado concreto que se espera alcanzar
H.3   Recursos asignados                    Presupuesto, personal, infraestructura destinada
H.4   Beneficiarios especificos             Grupos poblacionales objetivo
H.5   Zona geografica delimitada            Area especifica de aplicacion
H.6   Partes contratantes                   Sujetos de un convenio o tratado
H.7   Clausulas de reserva / salvaguarda    Protecciones ante circunstancias excepcionales
H.8   Mecanismos de solucion de controversias Arbitraje, mediacion, jurisdiccion internacional
H.9   Procedimiento de reforma              Como puede modificarse la norma
H.10  Quorum especial                       Mayorias requeridas para ciertas decisiones
H.11  Control de constitucionalidad         Revision por tribunales constitucionales
H.12  Referendum / Consulta previa          Participacion ciudadana en la aprobacion

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | H |
| Elementos      | 12 |
| Fase principal | 7 |
| Origenes       | base |
| Hash fuente    | 9480e890f660e126 |
