# CATEGORIA A — METADATOS DE IDENTIFICACION
# NP-CAT-A  v1.0.0-beta.1  2026-08-25T18:01:49-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 27 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
A.1   Tipo normativo                        Ley, decreto, resolucion, circular, acuerdo, acto administrativo, tratado, convenio, reglamento, ordenanza
A.2   Numero / Codigo                       Identificador numerico oficial (ej. Ley 1234 de 2024)
A.3   Titulo completo                       Denominacion formal de la norma
A.4   Titulo corto / Abreviatura            Nombre simplificado para referencia rapida
A.5   Autoridad emisora / Promulgante       Organo o entidad que expidio la norma
A.6   Autoridad que publica                 Entidad responsable de la publicacion oficial (DO, Boletin, etc.)
A.7   Fecha de expedicion / sancion         Fecha en que fue aprobada/sancionada
A.8   Fecha de publicacion                  Fecha de publicacion en medio oficial
A.9   Fecha de entrada en vigor             Fecha desde la cual produce efectos
A.10  Vacatio legis                         Plazo entre publicacion y entrada en vigor (si aplica)
A.11  Numero de publicacion oficial         Folio, pagina o referencia del Diario Oficial / Boletin
A.12  Identificador permanente (URN/ELI)    Identificador estandar (LexML URN, ELI europeo, etc.)
A.13  Idioma(s) de la norma                 Idioma oficial y traducciones
A.14  Ambito territorial de aplicacion      Donde aplica geograficamente
A.15  Ambito material de aplicacion         Sobre que materia versa
A.16  Jerarquia normativa / Rango           Constitucion, ley estatutaria, ley organica, ley ordinaria, decreto, resolucion, etc.
A.17  Firma / Autenticacion                 Quien firmo, sello, numero de acta, registro
A.18  Estado de publicacion                 Publicada, por publicar, publicacion parcial, publicacion diferida
A.19  Ambito personal de aplicacion         Quienes quedan sujetos (nacionales, extranjeros, personas juridicas)
A.20  Fecha de aplicabilidad                Fecha desde la cual es aplicable
A.21  Primera fecha de entrada en vigor     Fecha original de vigencia
A.22  Valor legal                           Fuerza obligatoria de la norma
A.23  Titular de derechos                   Entidad con derechos de autor
A.24  Licencia                              Tipo de licencia de uso
A.25  Formato                               PDF, HTML, XML, etc.
A.30  Caracter de la norma                  General (erga omnes), particular (inter partes), o mixto. Incluye efectos, publicidad, recursos y revocatoria diferenciados. [SSPD]
A.31  Publicidad de actos administrativos de la autoridad Reglas sobre como la autoridad publicita sus actos: medio (boletin, web, gaceta), periodicidad, plazo, proteccion de datos personales, archivo historico. [SSPD]

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | A |
| Elementos      | 27 |
| Fase principal | 1 |
| Origenes       | SSPD, base |
| Hash fuente    | 1e3e81391ae6fdfc |
