# CATEGORIA J — INTERPRETACION Y APLICACION
# NP-CAT-J  v1.0.0-beta.1  2026-08-25T18:01:50-0500

================================================================================
1.  DEFINICION
================================================================================

[Auto-generado desde data/elementos.json — 10 elementos]

================================================================================
2.  ELEMENTOS
================================================================================

#     Elemento                              Descripcion
----- ------------------------------------- -----------------------------------
J.1   Regla de interpretacion literal       Significado gramatical del texto
J.2   Regla de interpretacion sistematica   Concordancia con el resto del ordenamiento
J.3   Regla de interpretacion historica     Intencion del legislador (trabajos preparatorios)
J.4   Regla de interpretacion teleologica   Finalidad y objeto de la norma
J.5   Regla de interpretacion finalista / sociologica Efectos sociales de la aplicacion
J.6   Interpretacion restrictiva            Aplicacion limitada por principio de legalidad
J.7   Interpretacion extensiva              Ampliacion del sentido por analogia
J.8   Interpretacion conforme               Lectura compatible con normas superiores
J.9   Argumentos a contrario sensu          Lo que no dice la norma pero se infiere por exclusion
J.10  Integracion del derecho               Normas supletorias aplicables por vacio

================================================================================
3.  METADATOS
================================================================================

| Campo          | Valor |
|----------------|-------|
| Categoria      | J |
| Elementos      | 10 |
| Fase principal | 6 |
| Origenes       | base |
| Hash fuente    | 8ce4cb6008d145fc |
