# GLOSARIO DERIVADO
# NP-GLOSARIO  v1.0.0-beta.1  2026-08-25T18:01:51-0500
# Hash fuente: cd28f9451bceeab2

================================================================================
1.  TERMINOS EXTRAIDOS AUTOMATICAMENTE DE ELEMENTOS.JSON
================================================================================

**Total terminos:** 27

### AIR
**Elementos relacionados:** L.12

### alerta temprana
**Elementos relacionados:** M.15

### algoritmo
**Elementos relacionados:** F.72

### armonizacion
**Elementos relacionados:** M.16

### ciberseguridad
**Elementos relacionados:** F.71

### control de constitucionalidad
**Elementos relacionados:** H.11, I.5, I.6

### debido proceso
**Elementos relacionados:** M.2

### eficacia ultraactiva
**Elementos relacionados:** C.20, K.5

### erga omnes
**Elementos relacionados:** A.30

### estandar sectorial
**Elementos relacionados:** M.16

### evaluacion de impacto
**Elementos relacionados:** M.15

### explicabilidad
**Elementos relacionados:** F.72

### inteligencia artificial
**Elementos relacionados:** F.72

### inter partes
**Elementos relacionados:** A.30

### interconexion
**Elementos relacionados:** F.58

### interpretacion conforme
**Elementos relacionados:** C.18, J.8

### mesa tecnica
**Elementos relacionados:** M.16

### observatorio
**Elementos relacionados:** M.15

### plataforma digital
**Elementos relacionados:** F.70

### portal web
**Elementos relacionados:** F.70

### proteccion de datos
**Elementos relacionados:** F.71

### regulacion asimetrica
**Elementos relacionados:** F.62

### resiliencia
**Elementos relacionados:** F.71

### sistema de informacion
**Elementos relacionados:** F.70

### sunset clause
**Elementos relacionados:** L.15

### tarifa social
**Elementos relacionados:** F.42

### vacatio legis
**Elementos relacionados:** A.10, C.15
