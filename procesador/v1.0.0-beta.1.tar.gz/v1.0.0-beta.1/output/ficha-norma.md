# FICHA DE LECTURA MANUAL DE NORMAS
# NP-FICHA  v1.0.0-beta.1  2026-08-25T18:01:51-0500
# Hash fuente: cd28f9451bceeab2

================================================================================
INSTRUCCIONES DE USO
================================================================================

1. Complete cada campo marcando [x] o dejando [ ] segun aplique.
2. Use el campo VALOR para registrar el dato extraido.
3. Use REF. ARTICULO para citar la disposicion que sustenta el dato.
4. Use NOTAS para registrar observaciones, dudas o advertencias.
5. Al finalizar cada fase, tome la decision de continuidad.

**Total de campos:** 268
**Categorias:** 13 (A, B, C, D, E, F, G, H, I, J, K, L, M)
**Fases:** 10 (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)


================================================================================
FASE 0 — PREPARACION
================================================================================

### Categoria G (1 elementos)

- [ ] **G.4** — Proposito del analisis
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

---
**Decision Fase 0:** [ ] CONTINUAR  [ ] PAUSAR  [ ] ABANDONAR
**Firma:** _______________  **Fecha:** _______________


================================================================================
FASE 1 — IDENTIFICACION FORMAL
================================================================================

### Categoria A (27 elementos)

- [ ] **A.1** — Tipo normativo
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.2** — Numero / Codigo
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.3** — Titulo completo
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.4** — Titulo corto / Abreviatura
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.5** — Autoridad emisora / Promulgante
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.6** — Autoridad que publica
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.7** — Fecha de expedicion / sancion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.8** — Fecha de publicacion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.9** — Fecha de entrada en vigor
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.10** — Vacatio legis
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.11** — Numero de publicacion oficial
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.12** — Identificador permanente (URN/ELI)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.13** — Idioma(s) de la norma
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.14** — Ambito territorial de aplicacion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.15** — Ambito material de aplicacion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.16** — Jerarquia normativa / Rango
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.17** — Firma / Autenticacion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.18** — Estado de publicacion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.19** — Ambito personal de aplicacion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.20** — Fecha de aplicabilidad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.21** — Primera fecha de entrada en vigor
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.22** — Valor legal
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.23** — Titular de derechos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.24** — Licencia
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.25** — Formato
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.30** — Caracter de la norma
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **A.31** — Publicidad de actos administrativos de la autoridad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

### Categoria B (22 elementos)

- [ ] **B.1** — Preambulo / Exposicion de motivos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.2** — Titulo(s)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.3** — Capitulo(s)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.4** — Seccion(es) / Apartado(s)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.5** — Articulo(s)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.6** — Paragrafo(s)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.7** — Numeral(es) / Inciso(s)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.8** — Literal(es) / Letra(s)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.9** — Disposiciones adicionales
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.10** — Disposiciones transitorias
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.11** — Disposicion derogatoria
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.12** — Disposicion final
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.13** — Anexo(s) / Apendice(s)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.14** — Glosario / Definiciones
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.15** — Considerandos / Visto / Resuelvo
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.16** — Consideraciones / Fundamentos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.17** — Clausula de extincion / Termino
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.18** — Clausula de revision / Revision periodica
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.19** — Es anexo de
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.20** — Anexos tecnicos con contenido matematico
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.21** — Formatos obligatorios / Formularios
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **B.22** — Version de formatos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

### Categoria I (6 elementos)

- [ ] **I.1** — Rango en la jerarquia normativa
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **I.2** — Competencia para expedir
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **I.3** — Procedimiento de formacion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **I.4** — Vicios formales detectados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **I.5** — Control previo realizado
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **I.6** — Control posterior pendiente
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

---
**Decision Fase 1:** [ ] CONTINUAR  [ ] PAUSAR  [ ] ABANDONAR
**Firma:** _______________  **Fecha:** _______________


================================================================================
FASE 2 — VIGENCIA Y EFICACIA
================================================================================

### Categoria C (20 elementos)

- [ ] **C.1** — Vigente (sin modificaciones)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.2** — Vigente (modificada)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.3** — Derogada (total)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.4** — Derogada (parcial)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.5** — Caduca / Expirada
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.6** — Suspensa (eficacia suspendida)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.7** — Nula / Inexistente
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.8** — En tramite / Proyecto
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.9** — Vigente con reservas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.10** — Vigente con declaratoria de inexequibilidad parcial
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.11** — Vigente con sentencia de inconstitucionalidad condicionada
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.12** — Vigente con interpretacion autorizada
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.13** — Derogada tacitamente (por incompabilidad)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.14** — Consolidada (texto unificado)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.15** — Vigencia diferida (entrada en vigor aplazada)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.16** — Vigencia escalonada (por articulos o materias)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.17** — Vigente con eficacia diferida
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.18** — Vigente con interpretacion conforme
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.19** — Con efectos retroactivos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **C.20** — Con efectos ultraactivos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

### Categoria K (10 elementos)

- [ ] **K.1** — Eficacia inmediata
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **K.2** — Eficacia diferida
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **K.3** — Eficacia condicionada
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **K.4** — Eficacia retroactiva
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **K.5** — Eficacia ultraactiva
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **K.6** — Aplicabilidad personal
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **K.7** — Aplicabilidad material
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **K.8** — Aplicabilidad temporal
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **K.9** — Aplicabilidad territorial
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **K.10** — Inaplicabilidad por inconstitucionalidad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

---
**Decision Fase 2:** [ ] CONTINUAR  [ ] PAUSAR  [ ] ABANDONAR
**Firma:** _______________  **Fecha:** _______________


================================================================================
FASE 3 — VERSIONES
================================================================================

### Categoria E (13 elementos)

- [ ] **E.1** — Texto original
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.2** — Texto consolidado
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.3** — Historial de modificaciones
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.4** — Articulos modificados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.5** — Articulos derogados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.6** — Articulos adicionados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.7** — Articulos transitorios vigentes
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.8** — Notas de vigencia por articulo
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.9** — Fecha de ultima consolidacion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.10** — Versiones intermedias
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.11** — Marcas de cambio
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.12** — Texto anterior / Texto nuevo
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **E.13** — Version de formatos asociados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

---
**Decision Fase 3:** [ ] CONTINUAR  [ ] PAUSAR  [ ] ABANDONAR
**Firma:** _______________  **Fecha:** _______________


================================================================================
FASE 4 — RELACIONES NORMATIVAS
================================================================================

### Categoria D (20 elementos)

- [ ] **D.1** — Deroga (explicitamente)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.2** — Derogada por
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.3** — Modifica (a otra norma)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.4** — Modificada por
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.5** — Complementa (a otra norma)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.6** — Complementada por
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.7** — Desarrolla / Reglamenta
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.8** — Desarrollada / Reglamentada por
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.9** — Interpreta (a otra norma)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.10** — Interpretada por
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.11** — Confirma / Reitera
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.12** — Confirmada / Reiterada por
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.13** — Remite a otra norma (referencia)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.14** — Remitida por
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.19** — Es derivado de
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.20** — Basado en
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.21** — Corrige a
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.22** — Transposicion de directivas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.25** — Paquete normativo / Regimen normativo
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.25a** — Conceptos tecnicos y orientaciones regulatorias
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

### Categoria F (2 elementos)

- [ ] **F.41** — Mecanismos de ajuste y revision automatica
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.41a** — Indexadores y parametros de referencia
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

---
**Decision Fase 4:** [ ] CONTINUAR  [ ] PAUSAR  [ ] ABANDONAR
**Firma:** _______________  **Fecha:** _______________


================================================================================
FASE 5 — ANALISIS OPERATIVO
================================================================================

### Categoria F (65 elementos)

- [ ] **F.1** — Sujetos obligados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.2** — Sujetos beneficiarios
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.3** — Sujetos con facultades
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.4** — Objeto regulado
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.5** — Deberes / Obligaciones
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.6** — Prohibiciones
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.7** — Facultades / Potestades
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.8** — Derechos reconocidos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.9** — Procedimientos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.10** — Requisitos formales
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.10a** — Requisitos de diligenciamiento de formatos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.11** — Requisitos tecnicos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.12** — Plazos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.13** — Periodicidades
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.14** — Umbrales / Montos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.15** — Sanciones
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.16** — Excepciones
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.17** — Casos especiales
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.18** — Regimen transitorio
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.19** — Regimen especial
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.20** — Clausula de revision
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.21** — Clausula de salvaguarda
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.22** — Condicionantes
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.23** — Vacios normativos detectados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.24** — Ambiguedades detectadas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.25** — Contradicciones detectadas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.30** — Formulas de calculo / Algoritmos aplicables
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.30a** — Sistema de formulas / Grafo de dependencias
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.30b** — Formulas condicionales
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.30c** — Formulas iterativas o de convergencia
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.30d** — Orden de ejecucion de formulas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.30e** — Validacion cruzada entre formulas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.31** — Variables de entrada
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.32** — Procedimiento de calculo paso a paso
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.33** — Casos limite y excepciones de la formula
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.34** — Tablas de valores o matrices de referencia
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.36** — Metodologias tecnicas aplicables
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.36a** — Principios rectores de la metodologia
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.36b** — Criterios de validacion de la metodologia
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.36c** — Procedimiento de aprobacion de la metodologia
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.37** — Cronograma de implementacion / Fases
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.37a** — Hitos criticos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.37b** — Periodos de transicion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.42** — Subsidios, compensaciones y mecanismos de equidad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.42a** — Mecanismos de financiacion de subsidios
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.43** — Zonas tarifarias / Areas de servicio / Diferenciacion territorial
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.44** — Estandares tecnicos de referencia
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.45** — Modelos y simulaciones tecnicas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.46** — Escenarios y analisis de sensibilidad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.46a** — Matriz de riesgos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.51** — Penalidades progresivas y escalonadas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.57** — Facturacion, cobro, suspension y reconexion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.57a** — Prohibiciones de suspension y garantias de continuidad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.58** — Interconexion y acceso a infraestructura
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.60** — Medidas de urgencia y emergencia
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.61** — Liquidacion, extincion y traspaso de prestadores
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.62** — Regulacion asimetrica y poder de mercado
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.63** — Condiciones uniformes de servicio
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.64** — Tarifas reguladas vs. tarifas libres / precios de mercado
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.65** — Obligaciones de informacion al regulador / supervisor
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.66** — Medicion, verificacion y disputas de consumo
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.67** — Fondos sectoriales y compensaciones entre prestadores
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.70** — Sistemas de informacion y plataformas digitales
  - VALOR: _______________
  - REF. ARTICULO: _______________ (obligatorio)
  - NOTAS: _______________

- [ ] **F.71** — Ciberseguridad y proteccion de datos
  - VALOR: _______________
  - REF. ARTICULO: _______________ (obligatorio)
  - NOTAS: _______________

- [ ] **F.72** — Inteligencia artificial y algoritmos automatizados
  - VALOR: _______________
  - REF. ARTICULO: _______________ (obligatorio)
  - NOTAS: _______________

### Categoria M (16 elementos)

- [ ] **M.1** — Comites de seguimiento y veeduria
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.2** — Auditorias, verificaciones y control de calidad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.3** — Planes de accion, mejoramiento, contingencia y correccion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.4** — Mecanismos de participacion, consulta y veeduria
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.5** — Obligaciones de informacion y reporte
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.6** — Incentivos y bonificaciones
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.7** — Recursos y procedimientos de reclamacion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.8** — Garantias, seguros y responsabilidades
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.9** — Medidas cautelares, preventivas e intervencion forzosa
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.10** — Procedimiento sancionatorio
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.11** — Programa de fiscalizacion, inspeccion y vigilancia
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.12** — Mecanismos alternativos de solucion de conflictos (MASC)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.13** — Entidades de defensa del consumidor y veedurias sectoriales
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.14** — Calidad de atencion al usuario y canales obligatorios
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **M.15** — Observatorio sectorial de normativa
  - VALOR: _______________
  - REF. ARTICULO: _______________ (obligatorio)
  - NOTAS: _______________

- [ ] **M.16** — Mesa tecnica interinstitucional
  - VALOR: _______________
  - REF. ARTICULO: _______________ (obligatorio)
  - NOTAS: _______________

---
**Decision Fase 5:** [ ] CONTINUAR  [ ] PAUSAR  [ ] ABANDONAR
**Firma:** _______________  **Fecha:** _______________


================================================================================
FASE 6 — INTERPRETACION
================================================================================

### Categoria D (4 elementos)

- [ ] **D.15** — Principios generales del derecho aplicables
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.16** — Costumbre juridica aplicable
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.17** — Reglas de interpretacion aplicables
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **D.18** — Analogia / Integracion del derecho
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

### Categoria F (4 elementos)

- [ ] **F.35** — Indicadores / Metricas / KPIs de cumplimiento
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.35a** — Metas escalonadas de indicadores
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.35b** — Indicadores compuestos / Indices agregados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **F.35c** — Consecuencias por incumplimiento de indicadores
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

### Categoria J (10 elementos)

- [ ] **J.1** — Regla de interpretacion literal
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **J.2** — Regla de interpretacion sistematica
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **J.3** — Regla de interpretacion historica
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **J.4** — Regla de interpretacion teleologica
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **J.5** — Regla de interpretacion finalista / sociologica
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **J.6** — Interpretacion restrictiva
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **J.7** — Interpretacion extensiva
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **J.8** — Interpretacion conforme
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **J.9** — Argumentos a contrario sensu
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **J.10** — Integracion del derecho
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

---
**Decision Fase 6:** [ ] CONTINUAR  [ ] PAUSAR  [ ] ABANDONAR
**Firma:** _______________  **Fecha:** _______________


================================================================================
FASE 7 — ELEMENTOS ESPECIALES
================================================================================

### Categoria H (12 elementos)

- [ ] **H.1** — Plazo de duracion
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.2** — Objetivo especifico / Meta
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.3** — Recursos asignados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.4** — Beneficiarios especificos
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.5** — Zona geografica delimitada
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.6** — Partes contratantes
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.7** — Clausulas de reserva / salvaguarda
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.8** — Mecanismos de solucion de controversias
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.9** — Procedimiento de reforma
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.10** — Quorum especial
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.11** — Control de constitucionalidad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **H.12** — Referendum / Consulta previa
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

---
**Decision Fase 7:** [ ] CONTINUAR  [ ] PAUSAR  [ ] ABANDONAR
**Firma:** _______________  **Fecha:** _______________


================================================================================
FASE 8 — ANALISIS ECONOMICO / AIR
================================================================================

### Categoria L (20 elementos)

- [ ] **L.1** — Definicion del problema
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.2** — Objetivos de la norma
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.3** — Alternativas regulatorias consideradas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.4** — Costos de cumplimiento para particulares
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.5** — Costos de cumplimiento para el Estado
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.6** — Costos de oportunidad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.7** — Beneficios esperados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.8** — Impacto distributivo
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.9** — Impacto sectorial
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.10** — Impacto ambiental
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.11** — Consulta publica realizada
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.12** — Analisis de Impacto Regulatorio (AIR)
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.13** — Evaluacion ex post
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.14** — Indicadores de desempeno
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.15** — Sunset clause / Clausula de caducidad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.16** — Eficiencia normativa
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.17** — Carga administrativa
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.18** — Simplificacion propuesta
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.19** — Innovacion regulatoria
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **L.20** — Lecciones aprendidas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

---
**Decision Fase 8:** [ ] CONTINUAR  [ ] PAUSAR  [ ] ABANDONAR
**Firma:** _______________  **Fecha:** _______________


================================================================================
FASE 9 — CIERRE Y METADATOS
================================================================================

### Categoria G (16 elementos)

- [ ] **G.1** — Fecha del analisis
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.2** — Analista responsable
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.3** — Organizacion / Entidad
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.5** — Metodologia de analisis aplicada
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.6** — Nivel de profundidad del analisis
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.7** — Conflictos de interpretacion detectados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.8** — Dificultades encontradas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.9** — Consultas realizadas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.10** — Fuentes utilizadas
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.11** — Limitaciones del analisis
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.12** — Grado de certeza
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.13** — Recomendaciones
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.14** — Observaciones finales
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.15** — Metodologia de analisis aplicada
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.16** — Nivel de profundidad del analisis
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

- [ ] **G.17** — Conflictos de interpretacion detectados
  - VALOR: _______________
  - REF. ARTICULO: _______________
  - NOTAS: _______________

---
**Decision Fase 9:** [ ] CONTINUAR  [ ] PAUSAR  [ ] ABANDONAR
**Firma:** _______________  **Fecha:** _______________


================================================================================
RESUMEN EJECUTIVO
================================================================================

1. Norma analizada: _________________________________________________
2. Tipo y numero: _________________________________________________
3. Estado de vigencia: _________________________________________________
4. Elementos completados: _____ / 268
5. Elementos N/A: _____
6. Conflictos detectados: _____
7. Recomendaciones: _________________________________________________
8. Nivel de certeza: [ ] Alta  [ ] Media  [ ] Baja

================================================================================
CHECKLIST DE CALIDAD DEL ANALISIS (max. 50 puntos)
================================================================================

- [ ] Todos los metadatos de identificacion completos (A) ........... 5 pts
- [ ] Estructura formal mapeada (B) ................................. 5 pts
- [ ] Estado de vigencia verificado (C) ............................. 5 pts
- [ ] Relaciones normativas trazadas (D) ............................ 5 pts
- [ ] Versiones documentadas (E) .................................... 5 pts
- [ ] Analisis operativo completo (F+M) ............................. 10 pts
- [ ] Interpretacion aplicada (J) ................................... 5 pts
- [ ] Metadatos del analisis registrados (G) ........................ 5 pts
- [ ] Elementos especiales identificados (H) ........................ 5 pts

**PUNTUACION TOTAL: _____ / 50**

================================================================================
CIERRE DE LA FICHA
================================================================================

Analista: _____________________________  Firma: _____________________________
Revisor: _____________________________  Firma: _____________________________
Fecha de cierre: _____________________________
Archivo: _____________________________
